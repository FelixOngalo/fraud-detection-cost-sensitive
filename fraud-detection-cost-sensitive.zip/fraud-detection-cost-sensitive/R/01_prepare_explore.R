source("R/fraud_functions.R")
library(readr)
library(tidyr)

raw <- read_csv("data/raw/transactions_raw.csv", show_col_types = FALSE)
prep <- prepare_transactions(raw)
print(prep$log)
d <- prep$data
stopifnot(!anyDuplicated(d$transaction_id), all(is.finite(d$log_amount)), all(is.finite(d$log_ratio)))

# ---- Class imbalance and the accuracy illusion ----------------------------
balance <- d |> group_by(split) |>
  summarise(transactions = n(), frauds = sum(is_fraud), fraud_rate = mean(is_fraud),
            accuracy_if_nothing_flagged = 1 - mean(is_fraud),
            average_fraud_amount = mean(amount[is_fraud == 1]), average_legit_amount = mean(amount[is_fraud == 0]), .groups = "drop") |>
  mutate(split = factor(split, c("train", "valid", "test"))) |> arrange(split)
print(balance)

# ---- Fraud versus legitimate profile -------------------------------------
profile <- d |> group_by(is_fraud) |>
  summarise(median_amount = median(amount), median_log_ratio = median(log_ratio), share_night = mean(night), share_online = mean(channel == "online"),
            share_new_device = mean(new_device), share_country_mismatch = mean(country_mismatch), median_distance_km = median(distance_km),
            mean_txn_count_24h = mean(txn_count_24h), .groups = "drop")
print(profile)

# ---- Fraud rate by merchant category and hour block ------------------------
by_category <- d |> group_by(merchant_category) |> summarise(transactions = n(), fraud_rate = mean(is_fraud), .groups = "drop")
by_hour <- d |> mutate(hour_block = cut(hour, c(-1, 5, 11, 17, 23), labels = c("00-05", "06-11", "12-17", "18-23"))) |>
  group_by(hour_block) |> summarise(transactions = n(), fraud_rate = mean(is_fraud), .groups = "drop")
print(by_category); print(by_hour)

saveRDS(list(data = d, log = prep$log, balance = balance, profile = profile, by_category = by_category, by_hour = by_hour),
        "data/clean/transactions_prepared.rds")
