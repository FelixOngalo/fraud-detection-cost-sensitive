source("R/fraud_functions.R")
library(tidyr)
set.seed(2)

obj <- readRDS("data/clean/transactions_prepared.rds"); d <- obj$data
train <- d |> filter(split == "train"); valid <- d |> filter(split == "valid"); test <- d |> filter(split == "test")

# ---- Five ways to handle the imbalance ----------------------------------
predictors <- lapply(setNames(MODEL_NAMES, MODEL_NAMES), fit_model, df = train)
n_train_down <- nrow(downsample(train, 10))
raw_scores <- lapply(predictors, function(f) list(valid = as.numeric(f(valid)), test = as.numeric(f(test))))
models <- predictors

# ---- Calibration: fit Platt scaling on the validation set ----------------------
platt <- lapply(names(models), function(nm) platt_fit(valid$is_fraud, raw_scores[[nm]]$valid)); names(platt) <- names(models)
cal_scores <- lapply(names(models), function(nm) list(valid = platt_apply(platt[[nm]], raw_scores[[nm]]$valid),
                                                       test  = platt_apply(platt[[nm]], raw_scores[[nm]]$test)))
names(cal_scores) <- names(models)

# ---- Metrics on validation (model selection) and test (honest, with drift) --------
metric_row <- function(nm, set, df, sc_raw, sc_cal) {
  tf <- top_fraction(df$is_fraud, sc_cal, 0.01)
  tibble(model = nm, set = set, roc_auc = roc_auc(df$is_fraud, sc_raw), pr_auc = pr_auc(df$is_fraud, sc_raw),
         precision_top1pct = tf[["precision"]], recall_top1pct = tf[["recall"]],
         mean_predicted_raw = mean(sc_raw), brier_raw = brier(df$is_fraud, sc_raw), brier_calibrated = brier(df$is_fraud, sc_cal),
         observed_rate = mean(df$is_fraud))
}
metrics <- bind_rows(lapply(names(models), function(nm) bind_rows(
  metric_row(nm, "validation", valid, raw_scores[[nm]]$valid, cal_scores[[nm]]$valid),
  metric_row(nm, "test", test, raw_scores[[nm]]$test, cal_scores[[nm]]$test))))
print(metrics, width = 200)

# A baseline for PR-AUC: a random scorer has PR-AUC equal to the fraud rate
baseline_pr <- c(valid = mean(valid$is_fraud), test = mean(test$is_fraud))

# ---- Calibration tables on the test set (before and after Platt scaling) ----
calib <- bind_rows(lapply(c("Logistic (weighted x20)", "Random forest (plain)"), function(nm) bind_rows(
  calibration_table(test$is_fraud, raw_scores[[nm]]$test) |> mutate(model = nm, stage = "raw"),
  calibration_table(test$is_fraud, cal_scores[[nm]]$test) |> mutate(model = nm, stage = "calibrated"))))
print(calib, n = 40)

# ---- Pick the model by validation PR-AUC ---------------------------------
best <- metrics |> filter(set == "validation") |> slice_max(pr_auc, n = 1) |> pull(model)
cat("\nBest model by validation PR-AUC:", best, "\n")

# ---- What the final model uses (logistic coefficients and forest importance) --------
imp_rf <- attr(fit_model("Random forest (downsample 10:1)", train, importance = "permutation"), "fit")
importance <- tibble(feature = names(imp_rf$variable.importance), importance = unname(imp_rf$variable.importance)) |> arrange(desc(importance))
print(importance)

saveRDS(list(metrics = metrics, baseline_pr = baseline_pr, calib = calib, best = best, importance = importance,
             raw_scores = raw_scores, cal_scores = cal_scores, n_train_down = n_train_down, W = 20),
        "data/clean/model_results.rds")
