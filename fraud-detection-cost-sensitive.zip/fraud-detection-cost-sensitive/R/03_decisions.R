source("R/fraud_functions.R")
library(tidyr)
set.seed(3)

obj <- readRDS("data/clean/transactions_prepared.rds"); d <- obj$data
mod <- readRDS("data/clean/model_results.rds")
truth <- readRDS("data/clean/truth_fraud_type.rds")
train <- d |> filter(split == "train")
valid <- d |> filter(split == "valid") |> left_join(truth, by = "transaction_id")
test  <- d |> filter(split == "test")  |> left_join(truth, by = "transaction_id")
best <- mod$best
pv <- mod$cal_scores[[best]]$valid; pt <- mod$cal_scores[[best]]$test           # calibrated fraud probabilities
cat("Model used:", best, "\n")

# ---- 1. Choose decision rules on VALIDATION, evaluate on TEST ------------------
thr <- best_threshold(valid, pv)
cat("Cost-optimal single threshold on validation:", thr$threshold, "\n")
K <- 4                                                       # analyst capacity: alerts per day

policies <- bind_rows(
  policy_summary(test, rep(FALSE, nrow(test)), "No model: flag nothing"),
  policy_summary(test, mod$raw_scores[["Logistic (plain)"]]$test >= 0.5, "Default 0.5 on the plain logistic model (uncalibrated)"),
  policy_summary(test, mod$raw_scores[["Logistic (weighted x20)"]]$test >= 0.5, "Default 0.5 on the weighted logistic model (uncalibrated)"),
  policy_summary(test, pt >= 0.5, "Default 0.5 on calibrated probabilities of the chosen model"),
  policy_summary(test, rank(-pt, ties.method = "first") <= ceiling(0.01 * nrow(test)), "Flag the top 1% by probability"),
  policy_summary(test, pt >= thr$threshold, paste0("Cost-optimal threshold (", thr$threshold, ")")),
  policy_summary(test, expected_loss_flag(pt, test$loss_if_missed), "Expected-loss rule: p x loss > review cost"),
  policy_summary(test, capacity_flag(test, pt, K), paste0("Expected loss, at most ", K, " alerts per day")))
baseline_cost <- policies$total_cost[1]
policies <- policies |> mutate(savings_vs_no_model = baseline_cost - total_cost, savings_pct = 100 * savings_vs_no_model / baseline_cost)
print(policies, width = 200)

accuracy_illusion <- tibble(
  rule = c("Flag nothing", "Cost-optimal threshold"),
  accuracy = c(mean(test$is_fraud == 0), mean((pt >= thr$threshold) == (test$is_fraud == 1))),
  frauds_caught = c(0, sum(pt >= thr$threshold & test$is_fraud == 1)))
print(accuracy_illusion)

# Cost curve over thresholds on both sets
cost_curve <- bind_rows(thr$grid |> mutate(set = "validation"), best_threshold(test, pt)$grid |> mutate(set = "test"))

# ---- 2. Drift: the new tactic ("D") is the hard case ---------------------
recall_by_type <- function(df, p) df |> mutate(caught = p >= thr$threshold) |> filter(is_fraud == 1) |>
  group_by(fraud_type) |> summarise(frauds = n(), caught = sum(caught), recall = mean(caught), mean_amount = mean(amount), .groups = "drop")
by_type <- bind_rows(recall_by_type(valid, pv) |> mutate(period = "validation (before drift)"),
                     recall_by_type(test, pt) |> mutate(period = "test (after drift)"))
print(by_type)

missed_by_type <- test |> filter(is_fraud == 1, pt < thr$threshold) |> group_by(fraud_type) |>
  summarise(missed_frauds = n(), missed_loss = sum(loss_if_missed), .groups = "drop")
print(missed_by_type)

weekly <- test |> mutate(p = pt, week = (day - DRIFT_DAY) %/% 7 + 1) |> group_by(week) |>
  summarise(transactions = n(), frauds = sum(is_fraud), alerts = sum(p >= thr$threshold),
            recall = sum(p >= thr$threshold & is_fraud == 1) / pmax(sum(is_fraud), 1), mean_score = mean(p), .groups = "drop")
print(weekly)

score_psi <- psi(pv, pt)
feature_names <- c("log_amount", "log_ratio", "log_distance", "txn_count_24h")
feature_psi <- tibble(feature = feature_names, psi_valid_to_test = vapply(feature_names, function(f) psi(valid[[f]], test[[f]]), numeric(1)))
cat("\nScore PSI (validation -> test):", round(score_psi, 3), "\n"); print(feature_psi)
cat("Share of test frauds that are type D:", round(mean(test$fraud_type[test$is_fraud == 1] == "D"), 2), "\n")

# ---- 3. Would retraining on recent labels help? ----------------------------
# Use labels up to day DRIFT_DAY + 6 to retrain, the next 7 days to recalibrate and set the threshold,
# and the rest of the test period to compare with the old model. (In practice fraud labels arrive late.)
w1 <- test |> filter(day < DRIFT_DAY + 7); w2 <- test |> filter(day >= DRIFT_DAY + 7, day < DRIFT_DAY + 14); eval_set <- test |> filter(day >= DRIFT_DAY + 14)
new_pred <- fit_model(best, bind_rows(train, valid, w1))
pl <- platt_fit(w2$is_fraud, new_pred(w2))
new_thr <- best_threshold(w2, platt_apply(pl, new_pred(w2)))$threshold
p_new <- platt_apply(pl, new_pred(eval_set))
p_old <- pt[test$day >= DRIFT_DAY + 14]
retrain <- bind_rows(
  policy_summary(eval_set, rep(FALSE, nrow(eval_set)), "No model"),
  policy_summary(eval_set, p_old >= thr$threshold, "Original model, original threshold"),
  policy_summary(eval_set, p_new >= new_thr, "Retrained with first week of new regime")) |>
  mutate(savings_vs_no_model = total_cost[1] - total_cost)
print(retrain, width = 200)

saveRDS(list(policies = policies, accuracy_illusion = accuracy_illusion, cost_curve = cost_curve, threshold = thr$threshold,
             by_type = by_type, missed_by_type = missed_by_type, weekly = weekly, score_psi = score_psi, feature_psi = feature_psi, retrain = retrain,
             K = K, best = best, new_thr = new_thr, n_test_frauds = sum(test$is_fraud)),
        "data/clean/decision_results.rds")
