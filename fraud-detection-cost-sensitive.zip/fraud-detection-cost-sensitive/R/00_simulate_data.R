source("R/fraud_functions.R")
library(readr)

sim <- simulate_transactions(n = 100000, n_cust = 5000, seed = 2026, messy = TRUE)
write_csv(sim$raw, "data/raw/transactions_raw.csv")
saveRDS(sim$truth, "data/clean/truth_fraud_type.rds")     # used only for diagnostics, never for modelling
cat("Raw rows:", nrow(sim$raw), "\n")
